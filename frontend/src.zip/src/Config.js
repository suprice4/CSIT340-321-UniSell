const API_BASE = process.env.REACT_APP_API_URL || "http://localhost:8080";

export default API_BASE;