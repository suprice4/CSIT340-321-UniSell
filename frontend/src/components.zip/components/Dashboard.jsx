import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "./Navbar";
import Footer from "./Footer";
import { useToast } from "./Toast";
import "../styles/Dashboard.css";

// ─── Icons ────────────────────────────────────────────────────────────────────

const IconTrendUp = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/>
  </svg>
);
const IconRevenue = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
    <line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/>
  </svg>
);
const IconOrders = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
    <path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11"/>
  </svg>
);
const IconBox = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
    <path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/>
    <polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/>
  </svg>
);
const IconCustomers = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
    <path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/>
    <path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/>
  </svg>
);
const IconSearch = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#aaa" strokeWidth="2">
    <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
  </svg>
);
const IconExternalLink = () => (
  <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
    <path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"/>
    <polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/>
  </svg>
);

// ─── Data ─────────────────────────────────────────────────────────────────────

const SUMMARY_CARDS = [
  { label: "Total Revenue",   value: "₱284,500", change: "+12.4%", icon: <IconRevenue />,   color: "#e85d04" },
  { label: "Total Orders",    value: "1,340",    change: "+8.1%",  icon: <IconOrders />,    color: "#2563eb" },
  { label: "Products Sold",   value: "3,892",    change: "+5.3%",  icon: <IconBox />,       color: "#16a34a" },
  { label: "Total Customers", value: "876",      change: "+3.7%",  icon: <IconCustomers />, color: "#9333ea" },
];

const PLATFORM_DATA = [
  { name: "Shopee",      color: "#ee4d2d", orders: 580, revenue: "₱118,200", growth: "+14.2%", topProduct: "Wireless Earbuds", status: "Active" },
  { name: "Lazada",      color: "#0f146b", orders: 420, revenue: "₱96,700",  growth: "+9.8%",  topProduct: "Phone Case Set",   status: "Active" },
  { name: "TikTok Shop", color: "#555555", orders: 340, revenue: "₱69,600",  growth: "+18.5%", topProduct: "LED Desk Lamp",    status: "Active" },
];

// 6-month revenue data per platform
const CHART_MONTHS = ["Nov", "Dec", "Jan", "Feb", "Mar", "Apr"];
const CHART_SERIES = {
  Shopee:        [82000, 95000, 78000, 101000, 118200, 124000],
  Lazada:        [61000, 74000, 58000,  80000,  96700, 103000],
  "TikTok Shop": [38000, 52000, 45000,  56000,  69600,  78000],
};
const PLATFORM_LINE_COLORS = {
  Shopee: "#ee4d2d", Lazada: "#0f146b", "TikTok Shop": "#888",
};

const ALL_ORDERS = [
  { id: "#ORD-1041", customer: "Maria Santos",   platform: "Shopee",      product: "Wireless Earbuds",    amount: "₱850",   status: "Delivered",  date: "Apr 27, 2026" },
  { id: "#ORD-1040", customer: "Juan dela Cruz", platform: "Lazada",      product: "Phone Case Set",      amount: "₱320",   status: "Shipped",    date: "Apr 27, 2026" },
  { id: "#ORD-1039", customer: "Ana Reyes",      platform: "TikTok Shop", product: "LED Desk Lamp",       amount: "₱650",   status: "Pending",    date: "Apr 26, 2026" },
  { id: "#ORD-1038", customer: "Carlo Mendoza",  platform: "Shopee",      product: "USB-C Hub",           amount: "₱1,200", status: "Delivered",  date: "Apr 26, 2026" },
  { id: "#ORD-1037", customer: "Lea Villanueva", platform: "Lazada",      product: "Laptop Stand",        amount: "₱980",   status: "Processing", date: "Apr 25, 2026" },
  { id: "#ORD-1036", customer: "Ryan Torres",    platform: "TikTok Shop", product: "Mechanical Keyboard", amount: "₱2,100", status: "Delivered",  date: "Apr 25, 2026" },
  { id: "#ORD-1035", customer: "Sofia Lim",      platform: "Shopee",      product: "Ring Light",          amount: "₱750",   status: "Shipped",    date: "Apr 24, 2026" },
  { id: "#ORD-1034", customer: "Marco Aquino",   platform: "Lazada",      product: "Gaming Mouse",        amount: "₱1,450", status: "Cancelled",  date: "Apr 24, 2026" },
  { id: "#ORD-1033", customer: "Trisha Gomez",   platform: "TikTok Shop", product: "Ring Light",          amount: "₱750",   status: "Delivered",  date: "Apr 23, 2026" },
  { id: "#ORD-1032", customer: "Paolo Cruz",     platform: "Shopee",      product: "Wireless Earbuds",    amount: "₱850",   status: "Shipped",    date: "Apr 23, 2026" },
];

const STATUS_COLORS = {
  Delivered:  { bg: "#f0fff4", color: "#276749" },
  Shipped:    { bg: "#ebf8ff", color: "#2b6cb0" },
  Pending:    { bg: "#fefce8", color: "#854d0e" },
  Processing: { bg: "#faf5ff", color: "#6b21a8" },
  Cancelled:  { bg: "#fff5f5", color: "#9b2c2c" },
};
const PLATFORM_BADGE = {
  Shopee:        { bg: "#fff1ee", color: "#ee4d2d" },
  Lazada:        { bg: "#eef0ff", color: "#0f146b" },
  "TikTok Shop": { bg: "#f3f3f3", color: "#555" },
};

const PLATFORM_FILTERS = ["All", "Shopee", "Lazada", "TikTok Shop"];
const TAB_COLORS = { All: "#e85d04", Shopee: "#ee4d2d", Lazada: "#0f146b", "TikTok Shop": "#555" };
const ORDERS_PER_PAGE = 5;

// ─── Revenue Chart — pure SVG ─────────────────────────────────────────────────

function RevenueChart({ activePlatform }) {
  const [tooltip, setTooltip] = useState(null);
  const W = 680, H = 200;
  const pad = { top: 16, right: 16, bottom: 34, left: 58 };
  const cW = W - pad.left - pad.right;
  const cH = H - pad.top - pad.bottom;

  const showAll = activePlatform === "All";
  const platforms = showAll ? ["Shopee", "Lazada", "TikTok Shop"] : [activePlatform];

  // compute max
  let maxVal = 0;
  platforms.forEach((pl) => {
    const m = Math.max(...CHART_SERIES[pl]);
    if (m > maxVal) maxVal = m;
  });
  maxVal = Math.ceil(maxVal / 50000) * 50000;

  const toX = (i) => pad.left + (i / (CHART_MONTHS.length - 1)) * cW;
  const toY = (v) => pad.top + cH - (v / maxVal) * cH;

  const smooth = (pts) => {
    if (!pts.length) return "";
    let d = `M${pts[0][0]},${pts[0][1]}`;
    for (let i = 1; i < pts.length; i++) {
      const [px, py] = pts[i - 1], [cx, cy] = pts[i];
      const mx = (px + cx) / 2;
      d += ` C${mx},${py} ${mx},${cy} ${cx},${cy}`;
    }
    return d;
  };

  const area = (pts) => {
    const line = smooth(pts);
    if (!line) return "";
    return `${line} L${pts[pts.length - 1][0]},${pad.top + cH} L${pts[0][0]},${pad.top + cH} Z`;
  };

  const yTicks = [0, 0.25, 0.5, 0.75, 1];
  const fmtK = (v) => v >= 1000 ? `₱${(v / 1000).toFixed(0)}k` : `₱${v}`;

  const seriesData = platforms.map((pl) => ({
    name: pl,
    color: PLATFORM_LINE_COLORS[pl],
    pts: CHART_SERIES[pl].map((v, i) => [toX(i), toY(v)]),
    values: CHART_SERIES[pl],
  }));

  return (
    <div style={{ position: "relative" }}>
      <style>{`@keyframes dash{from{stroke-dashoffset:800}to{stroke-dashoffset:0}}`}</style>
      <svg viewBox={`0 0 ${W} ${H}`} style={{ width: "100%", height: "auto", display: "block" }}>
        <defs>
          {seriesData.map((s) => (
            <linearGradient key={s.name} id={`g-${s.name.replace(/\s/g,"")}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={s.color} stopOpacity="0.2"/>
              <stop offset="100%" stopColor={s.color} stopOpacity="0"/>
            </linearGradient>
          ))}
        </defs>

        {/* Y-axis grid */}
        {yTicks.map((f) => {
          const v = maxVal * f, y = toY(v);
          return (
            <g key={f}>
              <line x1={pad.left} y1={y} x2={W - pad.right} y2={y}
                stroke={f === 0 ? "#ddd" : "#f0f0f0"} strokeWidth="1"
                strokeDasharray={f === 0 ? undefined : "4,4"} />
              <text x={pad.left - 6} y={y + 4} fontSize="10" fill="#bbb" textAnchor="end">
                {fmtK(v)}
              </text>
            </g>
          );
        })}

        {/* Areas */}
        {seriesData.map((s) => (
          <path key={`a-${s.name}`} d={area(s.pts)}
            fill={`url(#g-${s.name.replace(/\s/g,"")})`} />
        ))}

        {/* Lines */}
        {seriesData.map((s) => (
          <path key={`l-${s.name}`} d={smooth(s.pts)}
            fill="none" stroke={s.color} strokeWidth="2.5"
            strokeLinecap="round" strokeDasharray="800" strokeDashoffset="0"
            style={{ animation: "dash 1s ease forwards" }} />
        ))}

        {/* Dots + hover targets */}
        {seriesData.map((s) =>
          s.pts.map(([x, y], i) => (
            <g key={`d-${s.name}-${i}`}>
              <circle cx={x} cy={y} r="3.5" fill={s.color} stroke="white" strokeWidth="2"/>
              <circle cx={x} cy={y} r="14" fill="transparent"
                onMouseEnter={() => setTooltip({ x, y, name: s.name, val: s.values[i], month: CHART_MONTHS[i] })}
                onMouseLeave={() => setTooltip(null)}
                style={{ cursor: "crosshair" }} />
            </g>
          ))
        )}

        {/* X labels */}
        {CHART_MONTHS.map((m, i) => (
          <text key={m} x={toX(i)} y={H - 6} fontSize="11" fill="#aaa" textAnchor="middle">{m}</text>
        ))}

        {/* Tooltip */}
        {tooltip && (
          <g>
            <rect x={Math.min(tooltip.x + 10, W - 125)} y={tooltip.y - 30} width="115" height="34"
              rx="6" fill="rgba(15,25,35,0.88)" />
            <text x={Math.min(tooltip.x + 10, W - 125) + 8} y={tooltip.y - 14}
              fontSize="11" fill="white" fontWeight="600">
              {tooltip.month} · {tooltip.name}
            </text>
            <text x={Math.min(tooltip.x + 10, W - 125) + 8} y={tooltip.y + 0}
              fontSize="12" fill="#fbbf24" fontWeight="700">
              ₱{tooltip.val.toLocaleString()}
            </text>
          </g>
        )}
      </svg>

      {/* Legend */}
      {showAll && (
        <div style={{ display: "flex", gap: "16px", justifyContent: "center", marginTop: "4px" }}>
          {seriesData.map((s) => (
            <div key={s.name} style={{ display: "flex", alignItems: "center", gap: "6px", fontSize: "12px", color: "var(--text-muted,#666)" }}>
              <div style={{ width: "18px", height: "3px", background: s.color, borderRadius: "2px" }} />
              {s.name}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────

export default function Dashboard() {
  const navigate = useNavigate();
  const toast    = useToast();

  const [activePlatformFilter, setActivePlatformFilter] = useState("All");
  const [searchQuery, setSearchQuery]   = useState("");
  const [filterStatus, setFilterStatus] = useState("All");
  const [currentPage, setCurrentPage]   = useState(1);
  const [greeting, setGreeting]         = useState("");
  const [chartPlatform, setChartPlatform] = useState("All");

  useEffect(() => {
    const h = new Date().getHours();
    setGreeting(h < 12 ? "Good morning" : h < 18 ? "Good afternoon" : "Good evening");
  }, []);

  useEffect(() => { setCurrentPage(1); }, [activePlatformFilter, filterStatus, searchQuery]);

  const visiblePlatforms = activePlatformFilter === "All"
    ? PLATFORM_DATA
    : PLATFORM_DATA.filter((p) => p.name === activePlatformFilter);

  const filteredOrders = ALL_ORDERS.filter((order) => {
    const matchPlatform = activePlatformFilter === "All" || order.platform === activePlatformFilter;
    const matchStatus   = filterStatus === "All" || order.status === filterStatus;
    const q = searchQuery.toLowerCase();
    const matchSearch =
      !q ||
      order.customer.toLowerCase().includes(q) ||
      order.id.toLowerCase().includes(q) ||
      order.product.toLowerCase().includes(q) ||
      order.platform.toLowerCase().includes(q) ||
      order.status.toLowerCase().includes(q) ||
      order.amount.replace(/[₱,]/g, "").includes(q);
    return matchPlatform && matchStatus && matchSearch;
  });

  const totalPages      = Math.ceil(filteredOrders.length / ORDERS_PER_PAGE);
  const paginatedOrders = filteredOrders.slice(
    (currentPage - 1) * ORDERS_PER_PAGE,
    currentPage * ORDERS_PER_PAGE
  );

  const handleProductLink = (productName) => {
    navigate(`/products?search=${encodeURIComponent(productName)}`);
    toast.info(`Navigating to product: ${productName}`);
  };

  // ── Styles ────────────────────────────────────────────────────────────────
  const s = {
    page:        { fontFamily: "'Segoe UI', sans-serif", background: "var(--page-bg, #f5f5f5)", color: "var(--text-primary, #222)", minHeight: "100vh" },
    main:        { padding: "32px 40px", maxWidth: "1200px", margin: "0 auto" },
    secTitle:    { fontSize: "16px", fontWeight: "700", color: "var(--text-primary, #222)", margin: "0 0 16px" },
    cardsGrid:   { display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "16px", marginBottom: "32px" },
    sumCard:     (accent) => ({ background: "var(--card-bg,#fff)", border: "1px solid var(--border-color,#e0e0e0)", borderRadius: "10px", padding: "20px", display: "flex", flexDirection: "column", gap: "10px", borderTop: `3px solid ${accent}` }),
    cardTop:     { display: "flex", alignItems: "center", justifyContent: "space-between" },
    cardLabel:   { fontSize: "13px", color: "var(--text-muted,#888)", fontWeight: "500" },
    cardIcon:    (c) => ({ width: "36px", height: "36px", borderRadius: "50%", background: c + "18", color: c, display: "flex", alignItems: "center", justifyContent: "center" }),
    cardValue:   { fontSize: "24px", fontWeight: "700", color: "var(--text-primary,#1a1a1a)" },
    cardChange:  { display: "flex", alignItems: "center", gap: "4px", fontSize: "12px", color: "#16a34a" },
    chartCard:   { background: "var(--card-bg,#fff)", border: "1px solid var(--border-color,#e0e0e0)", borderRadius: "10px", padding: "20px", marginBottom: "32px" },
    chartHead:   { display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "16px", flexWrap: "wrap", gap: "10px" },
    chartTabs:   { display: "flex", gap: "6px", flexWrap: "wrap" },
    chartTab:    (a) => ({ padding: "5px 14px", borderRadius: "6px", fontSize: "12px", fontWeight: "600", cursor: "pointer", border: "1px solid var(--border-color,#ddd)", background: a ? "#e85d04" : "var(--card-bg,#fff)", color: a ? "white" : "var(--text-muted,#555)", transition: "all 0.15s" }),
    platHead:    { display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "12px", flexWrap: "wrap", gap: "10px" },
    filterTabs:  { display: "flex", gap: "8px", flexWrap: "wrap" },
    filterTab:   (a, c) => ({ padding: "6px 16px", borderRadius: "20px", fontSize: "13px", fontWeight: "600", cursor: "pointer", border: `2px solid ${a ? c : "var(--border-color,#ddd)"}`, background: a ? c : "var(--card-bg,#fff)", color: a ? "white" : "var(--text-muted,#555)", transition: "all 0.15s" }),
    platGrid:    (n) => ({ display: "grid", gridTemplateColumns: n === 1 ? "minmax(0,400px)" : "repeat(3, 1fr)", gap: "16px", marginBottom: "32px" }),
    platCard:    (c) => ({ background: "var(--card-bg,#fff)", border: "1px solid var(--border-color,#e0e0e0)", borderRadius: "10px", padding: "20px", borderTop: `3px solid ${c}` }),
    platHeader:  { display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "14px" },
    platName:    (c) => ({ fontSize: "16px", fontWeight: "700", color: c }),
    platBadge:   { fontSize: "11px", background: "#f0fff4", color: "#276749", padding: "3px 10px", borderRadius: "12px", fontWeight: "600" },
    platRow:     { display: "flex", justifyContent: "space-between", fontSize: "13px", color: "var(--text-muted,#555)", marginBottom: "8px", alignItems: "center" },
    platVal:     { fontWeight: "600", color: "var(--text-primary,#222)" },
    platGrowth:  { display: "flex", alignItems: "center", gap: "4px", fontSize: "12px", color: "#16a34a", marginTop: "10px", fontWeight: "600" },
    tableCard:   { background: "var(--card-bg,#fff)", border: "1px solid var(--border-color,#e0e0e0)", borderRadius: "10px", padding: "20px" },
    tableTop:    { display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "16px", flexWrap: "wrap", gap: "12px" },
    filterRow:   { display: "flex", gap: "10px", flexWrap: "wrap", alignItems: "center" },
    searchWrap:  { display: "flex", alignItems: "center", gap: "8px", border: "1px solid var(--border-color,#ddd)", borderRadius: "6px", padding: "7px 12px", background: "var(--section-alt-bg,#fafafa)" },
    searchInput: { border: "none", background: "transparent", outline: "none", fontSize: "13px", color: "var(--text-primary,#444)", width: "170px" },
    filterSel:   { fontSize: "13px", padding: "7px 12px", border: "1px solid var(--border-color,#ddd)", borderRadius: "6px", background: "var(--section-alt-bg,#fafafa)", color: "var(--text-primary,#444)", outline: "none", cursor: "pointer" },
    table:       { width: "100%", borderCollapse: "collapse", fontSize: "13px" },
    th:          { padding: "10px 14px", textAlign: "left", fontWeight: "600", color: "var(--text-muted,#888)", borderBottom: "1px solid var(--border-color,#f0f0f0)", fontSize: "12px", textTransform: "uppercase", letterSpacing: "0.5px" },
    td:          { padding: "12px 14px", borderBottom: "1px solid var(--border-color,#f7f7f7)", color: "var(--text-primary,#333)" },
    badge:       (bg, color) => ({ display: "inline-block", background: bg, color, padding: "3px 10px", borderRadius: "12px", fontSize: "11px", fontWeight: "600" }),
    prodLink:    { background: "none", border: "none", color: "#2563eb", cursor: "pointer", fontSize: "13px", textDecoration: "none", display: "inline-flex", alignItems: "center", gap: "4px", padding: 0, fontFamily: "inherit" },
    pagination:  { display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: "16px", fontSize: "13px", color: "var(--text-muted,#888)" },
    pageBtn:     (a) => ({ padding: "5px 11px", borderRadius: "6px", border: "1px solid var(--border-color,#ddd)", background: a ? "#e85d04" : "var(--card-bg,#fff)", color: a ? "#fff" : "#555", cursor: "pointer", fontSize: "13px", fontWeight: a ? "600" : "400", marginLeft: "4px" }),
    emptyRow:    { textAlign: "center", padding: "32px", color: "var(--text-muted,#aaa)", fontSize: "14px" },
  };

  return (
    <div style={s.page}>
      <Navbar activePage="/dashboard" />
      <div style={s.main}>

        {/* Greeting */}
        <div style={{ marginBottom: "28px" }}>
          <h2 style={{ fontSize: "22px", fontWeight: "700", color: "var(--text-primary,#1a1a1a)", marginBottom: "4px" }}>
            {greeting}, Admin 👋
          </h2>
          <p style={{ fontSize: "14px", color: "var(--text-muted,#777)" }}>
            Here's what's happening across your platforms today.
          </p>
        </div>

        {/* ── Summary Cards ── */}
        <p style={s.secTitle}>Sales Overview</p>
        <div style={s.cardsGrid}>
          {SUMMARY_CARDS.map((card) => (
            <div key={card.label} style={s.sumCard(card.color)}>
              <div style={s.cardTop}>
                <span style={s.cardLabel}>{card.label}</span>
                <div style={s.cardIcon(card.color)}>{card.icon}</div>
              </div>
              <div style={s.cardValue}>{card.value}</div>
              <div style={s.cardChange}><IconTrendUp />{card.change} this month</div>
            </div>
          ))}
        </div>

        {/* ── Revenue Chart ── */}
        <div style={s.chartCard}>
          <div style={s.chartHead}>
            <p style={{ ...s.secTitle, margin: 0 }}>Revenue Trend (6 months)</p>
            <div style={s.chartTabs}>
              {["All", "Shopee", "Lazada", "TikTok Shop"].map((p) => (
                <button key={p} style={s.chartTab(chartPlatform === p)} onClick={() => setChartPlatform(p)}>
                  {p}
                </button>
              ))}
            </div>
          </div>
          <RevenueChart activePlatform={chartPlatform} />
        </div>

        {/* ── Platform Filter + Breakdown ── */}
        <div style={s.platHead}>
          <p style={{ ...s.secTitle, margin: 0 }}>Platform Breakdown</p>
          <div style={s.filterTabs}>
            {PLATFORM_FILTERS.map((pf) => (
              <button key={pf} style={s.filterTab(activePlatformFilter === pf, TAB_COLORS[pf])}
                onClick={() => setActivePlatformFilter(pf)}>
                {pf}
              </button>
            ))}
          </div>
        </div>
        <div style={s.platGrid(visiblePlatforms.length)}>
          {visiblePlatforms.map((p) => (
            <div key={p.name} style={s.platCard(p.color)}>
              <div style={s.platHeader}>
                <span style={s.platName(p.color)}>{p.name}</span>
                <span style={s.platBadge}>{p.status}</span>
              </div>
              <div style={s.platRow}><span>Total Orders</span><span style={s.platVal}>{p.orders}</span></div>
              <div style={s.platRow}><span>Revenue</span><span style={s.platVal}>{p.revenue}</span></div>
              <div style={s.platRow}>
                <span>Top Product</span>
                <button style={s.prodLink} onClick={() => handleProductLink(p.topProduct)}
                  title={`View ${p.topProduct} in Products`}>
                  {p.topProduct}&nbsp;<IconExternalLink />
                </button>
              </div>
              <div style={s.platGrowth}><IconTrendUp />{p.growth} vs last month</div>
            </div>
          ))}
        </div>

        {/* ── Recent Orders Table ── */}
        <div style={s.tableCard}>
          <div style={s.tableTop}>
            <p style={{ ...s.secTitle, margin: 0 }}>Recent Orders</p>
            <div style={s.filterRow}>
              <div style={s.searchWrap}>
                <IconSearch />
                <input type="text" placeholder="Search orders…" value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)} style={s.searchInput} />
              </div>
              <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)} style={s.filterSel}>
                <option value="All">All Status</option>
                {["Delivered", "Shipped", "Pending", "Processing", "Cancelled"].map((st) => (
                  <option key={st} value={st}>{st}</option>
                ))}
              </select>
            </div>
          </div>

          <table style={s.table}>
            <thead>
              <tr>
                {["Order ID", "Customer", "Platform", "Product", "Amount", "Status", "Date"].map((h) => (
                  <th key={h} style={s.th}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {paginatedOrders.length > 0 ? paginatedOrders.map((order) => (
                <tr key={order.id}>
                  <td style={{ ...s.td, fontWeight: "600", color: "#e85d04" }}>{order.id}</td>
                  <td style={s.td}>{order.customer}</td>
                  <td style={s.td}>
                    <span style={s.badge(PLATFORM_BADGE[order.platform]?.bg, PLATFORM_BADGE[order.platform]?.color)}>
                      {order.platform}
                    </span>
                  </td>
                  {/* ── Order → Product link ── */}
                  <td style={s.td}>
                    <button style={s.prodLink} onClick={() => handleProductLink(order.product)}
                      title="View in Products">
                      {order.product}&nbsp;<IconExternalLink />
                    </button>
                  </td>
                  <td style={{ ...s.td, fontWeight: "600" }}>{order.amount}</td>
                  <td style={s.td}>
                    <span style={s.badge(STATUS_COLORS[order.status]?.bg, STATUS_COLORS[order.status]?.color)}>
                      {order.status}
                    </span>
                  </td>
                  <td style={{ ...s.td, color: "var(--text-muted,#888)" }}>{order.date}</td>
                </tr>
              )) : (
                <tr><td colSpan={7} style={s.emptyRow}>No orders match your filters.</td></tr>
              )}
            </tbody>
          </table>

          <div style={s.pagination}>
            <span>
              Showing {filteredOrders.length === 0 ? 0 : (currentPage - 1) * ORDERS_PER_PAGE + 1}–
              {Math.min(currentPage * ORDERS_PER_PAGE, filteredOrders.length)} of {filteredOrders.length} orders
            </span>
            <div>
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((pg) => (
                <button key={pg} style={s.pageBtn(currentPage === pg)} onClick={() => setCurrentPage(pg)}>{pg}</button>
              ))}
            </div>
          </div>
        </div>

      </div>
      <Footer />
    </div>
  );
}
